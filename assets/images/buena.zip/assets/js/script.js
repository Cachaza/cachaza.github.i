var contadorMenu = 1;
function menu() {
    document.getElementById("myDropdown").classList.toggle("show");
}

window.onclick = function(event) {
    if (!event.target.matches('.menu-dropdown')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
          var openDropdown = dropdowns[i];
          if (openDropdown.classList.contains('show')) {
            openDropdown.classList.remove('show');
          }
        }
      }
}

//FUNCION PARA EL BOTON DE ARRIBA:

function subirArriba() {
  document.documentElement.scrollTop = 0; 
}


//Cambiar imagenes segun tamaño de pantalla:


//
//
//  const mediaQuery = window.matchMedia('(max-width: 991px)')
//
//  function handleTabletChange(e) {
//    // Check if the media query is true
//    if (mediaQuery.matches) {
//
//      document.getElementById("imagen1").src="assets/images/foto3.jpg";
//      document.getElementById("imagen2").src="assets/images/foto3.jpg";
//      document.getElementById("imagen3").src="assets/images/foto3.jpg";
//    } else {
//      document.getElementById("imagen1").src="assets/images/foto5.jpg";
//      document.getElementById("imagen3").src="assets/images/foto5.jpg";
//      document.getElementById("imagen2").src="assets/images/foto5.jpg";
//      }
//  }
//  
//  // Register event listener
//mediaQuery.addEventListener('change', handleTabletChange);
//handleTabletChange(mediaQuery);


//window.onresize = function() {
//  if (window.innerWidth < 991) {
//    document.getElementById("imagen1").src="assets/images/foto3.jpg";
//    document.getElementById("imagen2").src="assets/images/foto3.jpg";
//    document.getElementById("imagen3").src="assets/images/foto3.jpg";
//  } else {
//    document.getElementById("imagen1").src="assets/images/foto5.jpg";
//    document.getElementById("imagen3").src="assets/images/foto5.jpg";
//    document.getElementById("imagen2").src="assets/images/foto5.jpg";
//    }
//}